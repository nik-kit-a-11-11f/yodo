// Основной JavaScript для ТехноСфера
document.addEventListener('DOMContentLoaded', function() {
    console.log('ТехноСфера - интернет-магазин электроники');
    
    // Обработка добавления в корзину
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const productId = this.dataset.productId;
            const productName = this.dataset.productName;
            const productPrice = this.dataset.productPrice;
            
            addToCart(productId, productName, productPrice);
        });
    });
    
    // Анимация счетчика корзины
    updateCartCounter();
});

// Функция добавления в корзину
function addToCart(productId, productName, productPrice) {
    let cart = JSON.parse(localStorage.getItem('technosfera_cart')) || [];
    
    // Проверяем, есть ли товар уже в корзине
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: productId,
            name: productName,
            price: parseFloat(productPrice),
            quantity: 1
        });
    }
    
    // Сохраняем обновленную корзину
    localStorage.setItem('technosfera_cart', JSON.stringify(cart));
    
    // Обновляем счетчик
    updateCartCounter();
    
    // Показываем уведомление
    showNotification('Товар добавлен в корзину!');
}

// Обновление счетчика корзины
function updateCartCounter() {
    const cart = JSON.parse(localStorage.getItem('technosfera_cart')) || [];
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    const counterElement = document.querySelector('.cart-counter');
    if (counterElement) {
        counterElement.textContent = totalItems;
    }
    
    // Создаем/обновляем счетчик в навигации
    let navCounter = document.querySelector('.nav-cart-counter');
    if (!navCounter) {
        const cartLink = document.querySelector('a[href="cart.php"]');
        if (cartLink) {
            navCounter = document.createElement('span');
            navCounter.className = 'nav-cart-counter';
            navCounter.style.cssText = `
                background: #e74c3c;
                color: white;
                border-radius: 50%;
                padding: 2px 6px;
                font-size: 0.8rem;
                margin-left: 5px;
            `;
            cartLink.appendChild(navCounter);
        }
    }
    
    if (navCounter) {
        navCounter.textContent = totalItems;
        navCounter.style.display = totalItems > 0 ? 'inline-block' : 'none';
    }
}

// Показ уведомлений
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : '#e74c3c'};
        color: white;
        padding: 1rem 2rem;
        border-radius: 5px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 1000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Анимация появления
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Автоматическое скрытие
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Форматирование цены
function formatPrice(price) {
    return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
}

// Валидация формы
function validateForm(form) {
    const inputs = form.querySelectorAll('input[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.style.borderColor = '#e74c3c';
            isValid = false;
        } else {
            input.style.borderColor = '#27ae60';
        }
    });
    
    return isValid;
}