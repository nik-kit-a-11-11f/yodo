<?php
// Интернет-магазин "ТехноСфера" - Главная страница
session_start();
$page_title = "ТехноСфера - Интернет-магазин электроники";
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/catalog.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>ТехноСфера</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="catalog/">Каталог</a></li>
                    <li><a href="cart.php">Корзина</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <section class="hero">
            <h2>Добро пожаловать в мир технологий!</h2>
            <p>Лучшая электроника по доступным ценам</p>
            <a href="catalog/" class="btn">Смотреть каталог</a>
        </section>

        <section class="features">
            <div class="feature">
                <h3>🚚 Быстрая доставка</h3>
                <p>Доставка по всему городу за 24 часа</p>
            </div>
            <div class="feature">
                <h3>🔒 Гарантия качества</h3>
                <p>Все товары проходят проверку</p>
            </div>
            <div class="feature">
                <h3>💳 Удобная оплата</h3>
                <p>Наличные, карты, онлайн-платежи</p>
            </div>
        </section>

        <?php
        // Подключение к базе данных
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=technosfera_db', 'root', '');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Получаем популярные товары
            $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC LIMIT 3");
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if ($products) {
                echo '<section class="popular-products">';
                echo '<h2>Популярные товары</h2>';
                echo '<div class="products-grid">';
                
                foreach ($products as $product) {
                    echo '<div class="product-card">';
                    echo '<img src="images/products/' . $product['id'] . '.jpg" alt="' . $product['name'] . '">';
                    echo '<h3>' . $product['name'] . '</h3>';
                    echo '<p class="price">' . number_format($product['price'], 0, '', ' ') . ' ₽</p>';
                    echo '<a href="catalog/product.php?id=' . $product['id'] . '" class="btn">Подробнее</a>';
                    echo '</div>';
                }
                
                echo '</div></section>';
            }
        } catch (PDOException $e) {
            echo '<p class="error">Ошибка загрузки товаров: ' . $e->getMessage() . '</p>';
        }
        ?>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2023 ТехноСфера. Все права защищены.</p>
            <p>Телефон: +7 (495) 123-45-67</p>
        </div>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>