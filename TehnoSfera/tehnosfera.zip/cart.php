<?php
// Страница корзины
session_start();
$page_title = "Корзина - ТехноСфера";

// Обработка действий с корзиной
if ($_POST['action'] ?? '' === 'update') {
    // Обновление количества
    $cart = json_decode($_POST['cart_data'], true) ?? [];
    foreach ($_POST['quantity'] as $productId => $quantity) {
        $quantity = intval($quantity);
        if ($quantity > 0) {
            $cart[$productId]['quantity'] = $quantity;
        } else {
            unset($cart[$productId]);
        }
    }
    // Сохраняем обновленную корзину (в реальном приложении - в сессии или БД)
    echo '<script>localStorage.setItem("technosfera_cart", \'' . json_encode($cart) . '\');</script>';
}

// Получаем данные корзины из localStorage (в реальном приложении - из сессии/БД)
$cart = [];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/catalog.css">
</head>
<body>
    <header>
        <div class="container">
            <h1><a href="index.php" style="color: white; text-decoration: none;">ТехноСфера</a></h1>
            <nav>
                <ul>
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="catalog/">Каталог</a></li>
                    <li><a href="cart.php">Корзина</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="catalog-header">
            <h1>Корзина покупок</h1>
        </div>

        <div id="cart-content">
            <!-- Содержимое корзины будет загружено через JavaScript -->
            <div class="loading">Загрузка корзины...</div>
        </div>

        <div id="empty-cart" style="display: none; text-align: center; padding: 3rem;">
            <h2>Ваша корзина пуста</h2>
            <p>Добавьте товары из каталога</p>
            <a href="catalog/" class="btn">Перейти в каталог</a>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2023 ТехноСфера. Все права защищены.</p>
        </div>
    </footer>

    <script src="js/main.js"></script>
    <script>
        // Загрузка и отображение корзины
        function loadCart() {
            const cart = JSON.parse(localStorage.getItem('technosfera_cart')) || {};
            const cartContent = document.getElementById('cart-content');
            const emptyCart = document.getElementById('empty-cart');
            
            if (Object.keys(cart).length === 0) {
                cartContent.style.display = 'none';
                emptyCart.style.display = 'block';
                return;
            }
            
            let html = `
                <form method="POST" id="cart-form">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="cart_data" value='${JSON.stringify(cart)}'>
                    <table style="width: 100%; border-collapse: collapse; background: white; border-radius: 10px; overflow: hidden;">
                        <thead>
                            <tr style="background: #667eea; color: white;">
                                <th style="padding: 1rem; text-align: left;">Товар</th>
                                <th style="padding: 1rem; text-align: center;">Цена</th>
                                <th style="padding: 1rem; text-align: center;">Количество</th>
                                <th style="padding: 1rem; text-align: right;">Сумма</th>
                            </tr>
                        </thead>
                        <tbody>
            `;
            
            let total = 0;
            
            Object.values(cart).forEach(item => {
                const itemTotal = item.price * item.quantity;
                total += itemTotal;
                
                html += `
                    <tr style="border-bottom: 1px solid #eee;">
                        <td style="padding: 1rem;">
                            <strong>${item.name}</strong>
                        </td>
                        <td style="padding: 1rem; text-align: center;">
                            ${formatPrice(item.price)}
                        </td>
                        <td style="padding: 1rem; text-align: center;">
                            <input type="number" name="quantity[${item.id}]" 
                                   value="${item.quantity}" min="1" max="10" 
                                   style="width: 60px; padding: 5px; text-align: center;">
                        </td>
                        <td style="padding: 1rem; text-align: right;">
                            <strong>${formatPrice(itemTotal)}</strong>
                        </td>
                    </tr>
                `;
            });
            
            html += `
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3" style="padding: 1rem; text-align: right; font-weight: bold;">
                                    Итого:
                                </td>
                                <td style="padding: 1rem; text-align: right; font-weight: bold; font-size: 1.2rem;">
                                    ${formatPrice(total)}
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                    
                    <div style="margin-top: 2rem; display: flex; gap: 1rem; justify-content: flex-end;">
                        <button type="submit" class="btn" style="background: #27ae60;">
                            Обновить корзину
                        </button>
                        <a href="checkout.php" class="btn">
                            Оформить заказ
                        </a>
                    </div>
                </form>
            `;
            
            cartContent.innerHTML = html;
            cartContent.style.display = 'block';
            emptyCart.style.display = 'none';
        }
        
        function formatPrice(price) {
            return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
        }
        
        // Загружаем корзину при загрузке страницы
        document.addEventListener('DOMContentLoaded', loadCart);
    </script>
</body>
</html>