<?php
// Страница каталога товаров
session_start();
$page_title = "Каталог товаров - ТехноСфера";

// Подключение к БД
try {
    $pdo = new PDO('mysql:host=localhost;dbname=technosfera_db', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Получаем товары
    $stmt = $pdo->query("SELECT * FROM products ORDER BY name");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $error = "Ошибка загрузки каталога: " . $e->getMessage();
    $products = [];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/catalog.css">
</head>
<body>
    <header>
        <div class="container">
            <h1><a href="../index.php" style="color: white; text-decoration: none;">ТехноСфера</a></h1>
            <nav>
                <ul>
                    <li><a href="../index.php">Главная</a></li>
                    <li><a href="index.php">Каталог</a></li>
                    <li><a href="../cart.php">Корзина</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="catalog-header">
            <h1>Каталог товаров</h1>
            <p>Все товары в наличии</p>
        </div>

        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="filters">
            <div class="filter-group">
                <label for="category">Категория:</label>
                <select id="category">
                    <option value="">Все категории</option>
                    <option value="laptop">Ноутбуки</option>
                    <option value="phone">Смартфоны</option>
                    <option value="audio">Аудиотехника</option>
                </select>
            </div>
            <div class="filter-group">
                <label for="price">Цена до:</label>
                <input type="range" id="price" min="0" max="200000" value="200000">
                <span id="price-value">200 000 ₽</span>
            </div>
        </div>

        <div class="products-list">
            <?php foreach ($products as $product): ?>
                <div class="product-item">
                    <div class="product-image">
                        <?php
                        $icons = ['💻', '📱', '🎧', '⌚', '📷'];
                        $icon = $icons[$product['id'] % count($icons)] ?? '📦';
                        echo $icon;
                        ?>
                    </div>
                    <div class="product-info">
                        <h3 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p class="product-description"><?php echo htmlspecialchars($product['description']); ?></p>
                        <p class="product-price"><?php echo number_format($product['price'], 0, '', ' '); ?> ₽</p>
                        <button class="add-to-cart" 
                                data-product-id="<?php echo $product['id']; ?>"
                                data-product-name="<?php echo htmlspecialchars($product['name']); ?>"
                                data-product-price="<?php echo $product['price']; ?>">
                            Добавить в корзину
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <?php if (empty($products)): ?>
                <div class="error" style="grid-column: 1 / -1; text-align: center;">
                    Товары не найдены
                </div>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2023 ТехноСфера. Все права защищены.</p>
        </div>
    </footer>

    <script src="../js/main.js"></script>
    <script>
        // Фильтрация товаров
        document.getElementById('price').addEventListener('input', function() {
            const price = this.value;
            document.getElementById('price-value').textContent = 
                new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
            
            // Здесь можно добавить логику фильтрации
        });
    </script>
</body>
</html>